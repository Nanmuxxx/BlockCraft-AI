# 独立 React + TypeScript + Vite 工程

要求 Node.js >= 22.16。审查源码后，在本目录运行：

```sh
npm ci
npm run dev
npm run build
npm run preview
```

dev 的回环地址由 Vite 显示；build 产物位于 dist/。可编辑 src/App.tsx、src/components/ 和 src/data.ts。
无需 BlockCraft 网站、账号、API 或远程 Runtime。React/Vite 依赖来自 npm，需要用户自行联网安装。
package.json 固定直接依赖版本，随包附带 package-lock.json 锁定传递依赖，使用 npm ci 按锁文件安装。离线安装仅在完整缓存已具备时可运行 npm ci --offline；ZIP 本身不包含依赖。
制品 SRI 作为版本准入核对声明，不代表本导出器已下载并认证 npm 包或其传递依赖。

内置 form 保存记录，list 展示/编辑/删除记录，metric count/sum/average 自动更新；编辑保存会保留原记录 ID，取消编辑或删除正在编辑的记录不会留下编辑状态；业务数据保存在内存，刷新恢复导出的初始记录。
字段顺序按配置；桌面保留归一化坐标与 renderOrder 的层叠/DOM 顺序，未设置坐标的积木排在坐标区域下方，手机全部按 renderOrder 顺排。此工程是独立功能布局，不是编辑器像素快照。
CustomBlock 仅支持默认 React 组件接收 props、使用组件本地状态的独立协议。宿主状态槽、声明状态、事件、能力请求均拒绝。
provenance.json 记录准确 definitionId/versionDigest；src/components/custom/ 中保留原始源文本和相对模块路径。

## 安全和数据

第三方及 AI 生成源码必须由你自行审查。摘要与静态语法/import 检查不等于安全沙箱认证、语义类型检查或行为正确性证明。
导出器没有安装或运行这些源码；只有仓库中固定且经过哈希确认的人工样本可进入独立验收环境。
代码在你启动后可获得普通网页的能力，不提供 CustomBlock 隔离。请勿将秘密、真实个人记录或凭据交给未审查代码。
导出包含项目已存记录和参数；共享 ZIP 前自行确认数据。已知凭据/环境文件/宿主路径模式会被拒绝，但文本扫描无法识别所有秘密。
不要把此工程接入可信服务器自动执行，也不要把它视为已经通过安全 Viewer 的制品。
