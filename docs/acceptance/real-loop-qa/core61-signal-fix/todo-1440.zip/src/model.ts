export type Value = string | number | boolean;
export type Row = { id: string; values: Record<string, Value> };
export type Field = { id: string; name: string; required: boolean } & ({ type: 'text' | 'number' | 'boolean' | 'date' } | { type: 'select'; options: string[] });
export type Block = { id: string; name: string } & ({ type: 'form'; fieldIds: string[] } | { type: 'list'; fieldIds: string[] } | { type: 'metric'; aggregation: 'count' } | { type: 'metric'; aggregation: 'sum' | 'average'; fieldId: string });
export type Records = Record<string, Row[]>;
export type Project = {
  formatVersion: 2; revision: number;
  base: { spec: { version: 1; id: string; name: string; entities: { id: string; name: string; fields: Field[] }[]; blocks: Block[]; relations: { id: string; type: 'dataBinding'; blockId: string; entityId: string }[] }; records: Records; blockPositions: Record<string, { x: number; y: number }> };
  custom: { instances: { id: string; definitionId: string; versionDigest: string; props: Record<string, unknown> }[]; positions: Record<string, { x: number; y: number }>; states: Record<string, never> };
  renderOrder: { kind: 'builtin' | 'custom'; id: string }[];
};
