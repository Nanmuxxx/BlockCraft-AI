import { useState, type FormEvent } from 'react';
import type { Field, Row, Value } from '../model';
export default function FormBlock({ fields, initial, onSave, onCancel }: { fields: Field[]; initial?: Row; onSave: (values: Record<string, Value>) => void; onCancel?: () => void }) {
  const [error, setError] = useState('');
  const [values, setValues] = useState<Record<string, string | boolean>>(() => Object.fromEntries(fields.map(field => {
    const value = initial && Object.prototype.hasOwnProperty.call(initial.values, field.id) ? initial.values[field.id] : undefined;
    return [field.id, field.type === 'boolean' ? value === true : value === undefined ? '' : String(value)];
  })));
  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); const next: Record<string, Value> = {};
    for (const field of fields) {
      const current = values[field.id];
      if (field.type === 'boolean') { next[field.id] = current === true; continue; }
      const raw = String(current ?? '');
      if (raw.trim() === '') { if (field.required) { setError('请填写：' + field.name); return; } if (initial) next[field.id] = ''; continue; }
      if (field.type === 'number') { const value = Number(raw); if (!Number.isFinite(value)) { setError('无效数字'); return; } next[field.id] = value; }
      else { next[field.id] = raw; }
    }
    onSave(next); setError('');
    if (!initial) setValues(Object.fromEntries(fields.map(field => [field.id, field.type === 'boolean' ? false : ''])));
  }
  return <form onSubmit={submit}>{fields.map(field => <label key={field.id}>{field.name}{field.required ? ' *' : ''}
    {field.type === 'select' ? <select name={field.id} required={field.required} value={String(values[field.id] ?? '')} onChange={event => setValues(current => ({ ...current, [field.id]: event.target.value }))}><option value="">请选择</option>{field.options.map(value => <option key={value}>{value}</option>)}</select>
    : <input name={field.id} type={field.type === 'boolean' ? 'checkbox' : field.type === 'number' ? 'number' : field.type === 'date' ? 'date' : 'text'} step={field.type === 'number' ? 'any' : undefined} required={field.type !== 'boolean' && field.required} checked={field.type === 'boolean' ? values[field.id] === true : undefined} value={field.type === 'boolean' ? undefined : String(values[field.id] ?? '')} onChange={event => setValues(current => ({ ...current, [field.id]: field.type === 'boolean' ? event.target.checked : event.target.value }))} />}
  </label>)}<button type="submit">{initial ? '保存修改' : '保存'}</button>{initial && onCancel && <button type="button" onClick={onCancel}>取消编辑</button>}{error && <p role="alert">{error}</p>}</form>;
}
