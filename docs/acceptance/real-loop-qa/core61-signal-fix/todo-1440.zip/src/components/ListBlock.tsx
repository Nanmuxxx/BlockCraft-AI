import FormBlock from './FormBlock';
import type { Field, Row, Value } from '../model';
export default function ListBlock({ fields, rows, editing, onEdit, onDelete, onUpdate, onCancel }: { fields: Field[]; rows: Row[]; editing?: Row; onEdit: (id: string) => void; onDelete: (id: string) => void; onUpdate: (id: string, values: Record<string, Value>) => void; onCancel: () => void }) {
  return <div className="table-scroll"><table><thead><tr>{fields.map(field => <th key={field.id}>{field.name}</th>)}<th>操作</th></tr></thead>
    <tbody>{rows.map(row => <tr key={row.id} data-record-id={row.id}>{fields.map(field => { const value = Object.prototype.hasOwnProperty.call(row.values, field.id) ? row.values[field.id] : undefined; return <td key={field.id}>{typeof value === 'boolean' ? (value ? '是' : '否') : String(value ?? '')}</td>; })}<td><button type="button" onClick={() => onEdit(row.id)}>编辑</button><button type="button" onClick={() => onDelete(row.id)}>删除</button></td></tr>)}</tbody>
  </table>{rows.length === 0 && <p>暂无记录</p>}{editing && <FormBlock key={editing.id} fields={fields} initial={editing} onSave={values => onUpdate(editing.id, values)} onCancel={onCancel} />}</div>;
}
