import type { Block, Row } from '../model';
export default function MetricBlock({ block, rows }: { block: Extract<Block, { type: 'metric' }>; rows: Row[] }) {
  const numbers = block.aggregation === 'count' ? [] : rows.map(row => row.values[block.fieldId]).filter((value): value is number => typeof value === 'number');
  const sum = numbers.reduce((a, b) => a + b, 0);
  const value = block.aggregation === 'count' ? rows.length : block.aggregation === 'sum' ? sum : numbers.length ? sum / numbers.length : 0;
  return <output className="metric">{Number.isFinite(value) ? value : '数值超出范围'}</output>;
}
