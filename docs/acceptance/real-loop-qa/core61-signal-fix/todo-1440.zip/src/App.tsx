import { useState } from 'react';
import type { ComponentType, CSSProperties } from 'react';
import type { Records, Row, Block, Value } from './model';
import { project } from './data';
import FormBlock from './components/FormBlock';
import ListBlock from './components/ListBlock';
import MetricBlock from './components/MetricBlock';

export function updateRows(rows: Row[], id: string, values: Record<string, Value>): Row[] {
  return rows.map(row => {
    if (row.id !== id) return row;
    const next = { ...row.values };
    for (const [field, value] of Object.entries(values)) {
      if (value === '') delete next[field];
      else Object.defineProperty(next, field, { value, enumerable: true, configurable: true, writable: true });
    }
    return { ...row, id: row.id, values: next };
  });
}

// Records live only in this standalone app's memory. Reload restores exported data.
const customComponents: Record<string, ComponentType<any>> = {  };
function own<T>(values: Record<string, T>, key: string): T | undefined { return Object.prototype.hasOwnProperty.call(values, key) ? values[key] : undefined; }
export default function App() {
  const [records, setRecords] = useState<Records>(project.base.records);
  const [error, setError] = useState('');
  const [editing, setEditing] = useState<{ entity: string; id: string } | null>(null);
  const positionedHeight = Math.max(0, ...[...Object.values(project.base.blockPositions), ...Object.values(project.custom.positions)].map(position => position.y * 800 + 620));
  function add(entity: string, row: Row) { setRecords(current => ({ ...current, [entity]: [...(own(current, entity) ?? []), row] })); }
  function remove(entity: string, id: string) { setRecords(current => ({ ...current, [entity]: (own(current, entity) ?? []).filter(row => row.id !== id) })); setEditing(current => current?.entity === entity && current.id === id ? null : current); }
  function update(entity: string, id: string, values: Record<string, Value>) { if (!(own(records, entity) ?? []).some(row => row.id === id)) { setError('记录不存在，请重新选择'); setEditing(null); return; } setRecords(current => ({ ...current, [entity]: updateRows(own(current, entity) ?? [], id, values) })); setError(''); setEditing(null); }
  return <main><h1>{project.base.spec.name}</h1>{error && <p role="alert">{error}</p>}<div className="board" style={{ '--positioned-height': positionedHeight + 'px' } as CSSProperties}>{project.renderOrder.map((item, index) => {
    const position = item.kind === 'builtin' ? own(project.base.blockPositions, item.id) : own(project.custom.positions, item.id);
    // Normalized saved coordinates determine the desktop board; DOM/tab order stays renderOrder.
    const style = position ? { '--x': position.x, '--y': position.y, zIndex: index + 1 } as CSSProperties : undefined;
    if (item.kind === 'custom') {
      const instance = project.custom.instances.find(instance => instance.id === item.id)!;
      const Component = customComponents[instance.id];
      return <section key={'custom:' + item.id} data-block-id={item.id} data-positioned={!!position} className="block" style={style}><Component {...instance.props} /></section>;
    }
    const block: Block = project.base.spec.blocks.find(block => block.id === item.id)!;
    const binding = project.base.spec.relations.find(binding => binding.blockId === block.id)!;
    const entity = project.base.spec.entities.find(entity => entity.id === binding.entityId)!;
    const rows = own(records, entity.id) ?? [];
    const fields = block.type === 'metric' ? [] : block.fieldIds.map(id => entity.fields.find(field => field.id === id)!);
    return <section key={'builtin:' + item.id} data-block-id={item.id} data-positioned={!!position} className="block" style={style}><h2>{block.name}</h2>
      {block.type === 'form' ? <FormBlock fields={fields} onSave={values => add(entity.id, { id: crypto.randomUUID(), values })} /> : block.type === 'list' ? <ListBlock fields={fields} rows={rows} editing={editing?.entity === entity.id ? rows.find(row => row.id === editing.id) : undefined} onEdit={id => { if (!rows.some(row => row.id === id)) { setError('记录不存在，请重新选择'); setEditing(null); return; } setError(''); setEditing({ entity: entity.id, id }); }} onDelete={id => remove(entity.id, id)} onUpdate={(id, values) => update(entity.id, id, values)} onCancel={() => setEditing(null)} /> : <MetricBlock block={block} rows={rows} />}
    </section>;
  })}</div></main>;
}
